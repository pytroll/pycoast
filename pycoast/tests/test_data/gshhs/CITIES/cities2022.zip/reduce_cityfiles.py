#!/usr/bin/env python
# -*- coding: utf-8 -*-
# pycoast, Writing of coastlines, borders, and rivers to images in Python
#
# Copyright (C) 2011-2020 PyCoast Developers
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

#
# This script produces cities.red files you may need with PyCoast/SatPy
#
# 1. Download http://download.geonames.org/export/dump/cities5000.zip
# 2. Unzip this file and you get a cities5000.txt of about 11MB size
# 3. Put and run this script side by side with your cities5000.txt
# 4. Redirect stdout by "python reduce_cityfiles.py > cities5000.red"
# 5. You should get a cities5000.red with a file size of about 2.2MB
# 6. Move and rename cities5000.red to db_root_path/CITIES/cities.red
# 7. Below an explanation of all fields you get (index counts from 0)
# 8. If 2.2MB seems too much then you can start with cities15000.zip
#

import os

"""
The main 'geoname' table has the following fields :
---------------------------------------------------
geonameid         : integer id of record in geonames database
name              : name of geographical point (utf8) varchar(200)
asciiname         : name of geographical point in plain ascii characters, varchar(200)
alternatenames    : alternatenames, comma separated, ascii names automatically transliterated, convenience attribute from alternatename table, varchar(10000)
latitude          : latitude in decimal degrees (wgs84)
longitude         : longitude in decimal degrees (wgs84)
feature class     : see http://www.geonames.org/export/codes.html, char(1)
feature code      : see http://www.geonames.org/export/codes.html, varchar(10)
country code      : ISO-3166 2-letter country code, 2 characters
cc2               : alternate country codes, comma separated, ISO-3166 2-letter country code, 200 characters
admin1 code       : fipscode (subject to change to iso code), see exceptions below, see file admin1Codes.txt for display names of this code; varchar(20)
admin2 code       : code for the second administrative division, a county in the US, see file admin2Codes.txt; varchar(80)
admin3 code       : code for third level administrative division, varchar(20)
admin4 code       : code for fourth level administrative division, varchar(20)
population        : bigint (8 byte int)
elevation         : in meters, integer
dem               : digital elevation model, srtm3 or gtopo30, average elevation of 3''x3'' (ca 90mx90m) or 30''x30'' (ca 900mx900m) area in meters, integer. srtm processed by cgiar/ciat.
timezone          : the iana timezone id (see file timeZone.txt) varchar(40)
modification date : date of last modification in yyyy-MM-dd format
"""

textfilename = 'cities5000.txt'
try:
    f = open(textfilename, mode='r', encoding='utf-8')
except FileNotFoundError:
    raise FileNotFoundError('Could not find file %s' % textfilename)
try:
    s = f.readline()
except IOError:
    raise IOError('Could not read file %s' % textfilename)

# Capitals: If you want to filter just Capitals these have 'feature code' t[7] == 'PPLC'
# MegaCities: You can also filter for MegaCities using 'population' int(t[14]) >= 1000000

# Iterate through lines
while s != '':
    t = s.split('\t')
    # Used: Name, ASCIIname, lon, lat, CountryCode
    t=t[1]+'\t'+t[2]+'\t'+t[5]+'\t'+t[4]+'\t'+t[8]
    print(t)
    # Read next line
    s = f.readline()
f.close()

