PyCoast can overlay 'cities' that you simply specify by name.
It reads locations from a file db_root_path/CITIES/cities.txt.
This is a tab delimited text file that has only five fields:
name, asciiname, longitude, latitude, country code (ISO-3166)

We produced 5 different files based on files cities5000.zip and
cities15000.zip that can be downloaded from  www.geonames.org.

megacities_rs.txt              Cities with population > 1000000
cities15000_rs.txt             Cities with population > 15000
cities5000_rs.txt              Cities with population > 5000
capitals_rs.txt                Capitals only
testcities_rs.txt              This is for PyCoast developers only

Move the file that best fits your needs from archive cities2022.zip
to db_root_path/CITIES/cities.txt (YOU HAVE TO RENAME IT cities.txt).
Most users may want to install cities15000_rs.txt or cities5000_rs.txt.
For more information check README_GeoNames.txt and reduce_cityfiles.py.
BTW "_rs" means reduced (to about 20% of the original size) and sorted.
