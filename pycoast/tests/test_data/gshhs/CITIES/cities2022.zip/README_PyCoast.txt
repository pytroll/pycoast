PyCoast can overlay 'cities' that you simply specify by name.
It reads locations from a file db_root_path/CITIES/cities.red
This is a tab delimited text file that has only five fields:
name, asciiname, longitude, latitude, country code (ISO-3166)

The suffix red is used to prevent it from opening in browsers.
We produced 5 different files based on files cities5000.zip and
cities15000.zip that can be downloaded from  www.geonames.org.

Cities with population>1000000  17881 May 10 08:18 megacities.red
Cities with population>15000  1055618 May 10 08:24 cities15000.red
Cities with population>5000   2181013 May 10 08:20 cities5000.red
Capitals only                    9463 May 10 08:26 capitals.red
For PyCoast developers only       950 May 10 08:47 test_cities.red

Move the file that best fits your needs from archive cities2022.zip
(no need to decompress everything) to db_root_path/CITIES/cities.red
Most users probably want to install cities15000.red or cities5000.red
For more information check README_GeoNames.txt and reduce_cityfiles.py